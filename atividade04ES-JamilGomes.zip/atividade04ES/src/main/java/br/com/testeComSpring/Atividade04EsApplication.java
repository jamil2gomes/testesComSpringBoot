package br.com.testeComSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade04EsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Atividade04EsApplication.class, args);
	}

}
