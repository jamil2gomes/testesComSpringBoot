package br.com.testeComSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade04EsApplicationTests {

	@Test
	void contextLoads() {
	}

}
